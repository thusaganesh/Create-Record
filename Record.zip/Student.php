<?php
    $studentsJson = '[
        {"sid": 1, "name": "Abirna", "age": 20, "address": "123 Maple Street", "cgpa": 3.8},
        {"sid": 2, "name": "Jenu", "age": 21, "address": "456 Oak Avenue", "cgpa": 3.6},
        {"sid": 3, "name": "Kani", "age": 22, "address": "789 Pine Road", "cgpa": 3.7},
        {"sid": 4, "name": "Mathi", "age": 23, "address": "101 Birch Boulevard", "cgpa": 3.6},
        {"sid": 5, "name": "Vijensi", "age": 24, "address": "202 Cedar Court", "cgpa": 3.4}
    ]';

    $students = json_decode($studentsJson, true);

    if (isset($_GET['sid'])) {
        $sid = $_GET['sid'];
        
        foreach ($students as $student) {
            if ($student['sid'] == $sid) {
                echo json_encode($student);
                exit;
            }
        }
        
        echo json_encode(['error' => 'Student not found']);
    } else {
        echo json_encode(['error' => 'No student ID provided']);
    }
?>